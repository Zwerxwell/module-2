import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from tkinter.font import Font


STOCKS = {
    'Google': {'price': 165.98, 'amount': 1000},
    'Apple': {'price': 228.8, 'amount': 5000},
    'Microsoft': {'price': 380.45, 'amount': 2500}
}

STOCKS2={
    'Tesla': {'price': 800.0, 'amount': 2000},
    'Amazon': {'price': 3000.0, 'amount': 1000}
}

STOCKS1={
    'NVIDIA': {'price': 500.0, 'amount': 1500},
    'Adobe': {'price': 450.0, 'amount': 1200}
}

USER_PORTFOLIO = {}
USER_STOCK_VALUE = {}  

ALL_STOCKS = {**STOCKS, **STOCKS1, **STOCKS2}


for stock in ALL_STOCKS:
    USER_PORTFOLIO[stock] = 0  
    USER_STOCK_VALUE[stock] = 0  

def update_purchase_history(purchases):
    history_table.delete(*history_table.get_children())  
    for i, purchase in enumerate(purchases):
        action = "Bought" if purchase[3] else "Sold"  
        history_table.insert(
            '', 'end',
            text=purchase[0],
            values=(action, purchase[1], f'${purchase[2]:,.2f}', f'{purchase[4]:,.2f}')  
        )

def update_stocks_frame():
    for child in stocks_frame.winfo_children():
        child.destroy()

    row = 0
    for stock, data in ALL_STOCKS.items():
        stock_label = ttk.Label(
            stocks_frame,
            text=f"{stock}: Цена ${data['price']}, Доступно: {data['amount']}, Сумма в портфеле: ${USER_STOCK_VALUE[stock]:,.2f}" 
        )
        stock_label.grid(row=row, column=0, sticky='w', pady=5)
        row += 1

def handle_buy_stock():
    selected_stock = stock_var.get()
    try:
        amount = int(amount_entry.get().strip())
    except ValueError:
        messagebox.showerror("Ошибка ввода", "Укажите корректное количество акций!")
        return

    if not selected_stock or selected_stock == 'Выберите акцию':
        messagebox.showerror("Ошибка выбора", "Пожалуйста, выберите акцию!")
        return
    elif amount <= 0:
        messagebox.showerror("Ошибка количества", "Количество должно быть больше нуля!")
        return
    elif ALL_STOCKS[selected_stock]['amount'] < amount:
        messagebox.showerror(
            f"Недостаточно акций {selected_stock}",
            f"На складе осталось всего {ALL_STOCKS[selected_stock]['amount']} акций."
        )
        return

    
    ALL_STOCKS[selected_stock]['amount'] -= amount
    USER_PORTFOLIO[selected_stock] += amount  

    
    total_cost = amount * ALL_STOCKS[selected_stock]['price']
    USER_STOCK_VALUE[selected_stock] += total_cost

    purchases.append((
        selected_stock,              
        amount,                      
        ALL_STOCKS[selected_stock]['price'],  
        True,                        
        total_cost                   
    ))

    update_purchase_history(purchases)
    messagebox.showinfo(
        "Покупка успешно завершена",
        f"Покупка {amount} акций {selected_stock} по цене ${ALL_STOCKS[selected_stock]['price']} за штуку выполнена! Общая стоимость: ${total_cost:,.2f}"
    )
    update_stocks_frame()

def handle_sell_stock():
    selected_stock = stock_var.get()
    try:
        amount = int(amount_entry.get().strip())
    except ValueError:
        messagebox.showerror("Ошибка ввода", "Укажите корректное количество акций!")
        return

    if not selected_stock or selected_stock == 'Выберите акцию':
        messagebox.showerror("Ошибка выбора", "Пожалуйста, выберите акцию!")
        return
    elif amount <= 0:
        messagebox.showerror("Ошибка количества", "Количество должно быть больше нуля!")
        return
    elif USER_PORTFOLIO[selected_stock] < amount:
        messagebox.showerror(
            f"У вас недостаточно акций {selected_stock}",
            f"В вашем портфеле всего {USER_PORTFOLIO[selected_stock]} акций."
        )
        return

    
    ALL_STOCKS[selected_stock]['amount'] += amount
    USER_PORTFOLIO[selected_stock] -= amount 

    
    total_cost = amount * ALL_STOCKS[selected_stock]['price']
    USER_STOCK_VALUE[selected_stock] -= total_cost

    purchases.append((
        selected_stock,              
        amount,                      
        ALL_STOCKS[selected_stock]['price'],  
        False,                       
        total_cost                   
    ))

    update_purchase_history(purchases)
    messagebox.showinfo(
        "Продажа успешно завершена",
        f"Продажа {amount} акций {selected_stock} по цене ${ALL_STOCKS[selected_stock]['price']} за штуку выполнена! Общая стоимость: ${total_cost:,.2f}"
    )
    update_stocks_frame()

def main():
    global root, stock_var, amount_entry, purchases, stocks_frame, history_table

    root = tk.Tk()
    root.title("Биржа акций")
    root.geometry("800x600")

    default_font = Font(family="Arial", size=14)
    header_font = Font(family="Arial", size=18, weight="bold")

    content_frame = ttk.Frame(root, padding=(15, 15))
    content_frame.pack(fill='both', expand=True)

    title_label = ttk.Label(content_frame, text="Биржа акций", font=header_font)
    title_label.pack(side='top', fill='x', pady=(0, 30))

    stocks_frame = ttk.Frame(content_frame, borderwidth=2, relief='groove', padding=(10, 10))
    stocks_frame.pack(side='left', fill='y', padx=(0, 25))

    purchase_frame = ttk.Frame(content_frame, borderwidth=2, relief='groove', padding=(10, 10))
    purchase_frame.pack(side='right', fill='y')

    history_frame = ttk.Frame(content_frame, borderwidth=2, relief='groove', padding=(10, 10))
    history_frame.pack(side='bottom', fill='both', expand=True)

    update_stocks_frame()

    stock_var = tk.StringVar(value='Выберите акцию')
    stock_options = list(ALL_STOCKS.keys())
    stock_dropdown = ttk.Combobox(
        purchase_frame,
        values=stock_options,
        state="readonly",
        textvariable=stock_var,
        width=20
    )
    stock_dropdown.grid(row=0, column=0, columnspan=2, pady=10, sticky='ew')

    amount_entry = ttk.Entry(purchase_frame, width=8)
    amount_entry.insert(0, "Количество")
    amount_entry.grid(row=1, column=0, pady=10, sticky='ew')

    buy_button = ttk.Button(purchase_frame, text="Купить", command=handle_buy_stock)
    buy_button.grid(row=1, column=1, pady=10, sticky='ew')

    sell_button = ttk.Button(purchase_frame, text="Продать", command=handle_sell_stock)
    sell_button.grid(row=2, column=1, pady=10, sticky='ew')

    history_label = ttk.Label(history_frame, text="История операций", font=default_font)
    history_label.pack(side='top', fill='x', pady=(0, 10))

    columns = ('Акция', 'Операция', 'Количество', 'Цена', 'Общая стоимость')  
    history_table = ttk.Treeview(history_frame, columns=columns, show='headings', height=10)
    history_table.pack(side='bottom', fill='both', expand=True)

    for col in columns:
        history_table.heading(col, text=col)
        history_table.column(col, stretch=True, minwidth=50, width=120)

    purchases = []

    root.mainloop()

if __name__ == "__main__":
    main()